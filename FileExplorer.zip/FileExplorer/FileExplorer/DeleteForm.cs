﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileExplorer
{
    public partial class DeleteForm : Form
    {
        Button yes;
        Button no;
        public DeleteForm()
        {
            InitializeComponent();
            yes =
            no= button2;
            yes.Click += Yes_Click;
        }

        private void Yes_Click(object? sender, EventArgs e)
        {
            try
            {
                File.Delete(Form1.copy_object);
                //dismiss the form
                this.Hide();
            }
            catch (Exception m)
            {
                MessageBox.Show(m.Message);
            }
        }
       private void DeleteForm_Load(object? sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The file" + "\n" + Form1.copy_object + "\n" + "deleted sucesfully");
            this.Hide();
        }
    }
}
