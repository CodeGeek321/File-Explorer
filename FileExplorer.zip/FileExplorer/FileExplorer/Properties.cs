﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileExplorer
{
    public partial class Properties : Form
    {
        public Properties()
        {
            InitializeComponent();
        }
        //set the getters and setters for the labels
        public  Label GetLabel
        {
            get
            {
                return label4;
            }
        }
        public Label GetDateLabel
        {
            get
            {
                return label5;
            }
        }
    }
}
