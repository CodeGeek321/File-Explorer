using System.Diagnostics;
using System.Timers;
namespace FileExplorer
{
    public partial class Form1 : Form
    {
        //declare a global treeview items
        TreeNode[] listViewItems;
        TreeNode[] items;
        string path = "C:\\Users\\USER\\Downloads\\Video";
       
        string current_path = "";
        int pValue = 0;
        //co-ordinates to store the mouse event
        int context_X=0;
        int context_Y=0;    

        //use a timer to update the value of the progress bar
        System.Timers.Timer progress_update =new System.Timers.Timer(1000);
        Form2 form2;
        ProgressBar progress;
        ImageList imageList;
        //access a graphics context from the current window

        //string used to hold the path of the copied file or directory
        public static string copy_object;
        string[] myvalues;
        public Form1()
        {
            InitializeComponent();
            //register a listener for that tsssimer
            progress_update.Elapsed += Progress_update_Elapsed;
            //read all the nodes in the parent path
            string[] files=Directory.GetFiles(path);
            
            //trim the trailing path from the root folder
            listViewItems=new TreeNode[files.Length];
            for(int i = 0; i < files.Length; i++)
            {
                listViewItems[i] = new TreeNode(files[i]);
            }
            //change the orientation of the items
            treeView1.Nodes.AddRange(listViewItems);
            //add the range to the listview

            //register an oncontext menu listener for
            //the item 
            treeView1.NodeMouseClick += TreeView1_NodeMouseClick;
            //register an onclick listener for the contextmenuitems
            contextMenuStrip2.ItemClicked += ContextMenuStrip2_ItemClicked;
            //get the system date and time
            DateTime dateTime=DateTime.Now;
            date_display.Text = dateTime.ToString();
            form2= new Form2();
            progress = form2.MyProgressBar;

            
            imageList= new ImageList();
            imageList.TransparentColor = Color.Blue;
            imageList.ColorDepth = ColorDepth.Depth32Bit;
            imageList.ImageSize = new Size(30, 30);
            //add images to the list
            imageList.Images.Add(Image.FromFile("folder_icon.png"));
            imageList.Images.Add(Image.FromFile("file_icon.jpg"));
            treeView1.ImageList = imageList;
            //run a process in the constructor to check if
            //the node is a directory or a file
            CheckStatus();
            

            //register a listener for file context menu
          
            treeView1.NodeMouseDoubleClick += TreeView1_NodeMouseDoubleClick; ;
            //register a listener for the form maximize event
            current_path = path;
            currentpath.Text = path;
            copy_object = path;
            //hide the top current path display
            label2.Visible = false;
            //register  al listener for the text box changed listener
            textBox1.TextChanged += TextBox1_TextChanged;

            myvalues = new string[] { "Frequently Accessed","Documents","Downloads","Pictures","Videos","This PC"
            ,"Network"};
            TreeNode[] treeview2nodes=new TreeNode[myvalues.Length];
            for(int u = 0; u < myvalues.Length; u++)
            {
                treeview2nodes[u]= new TreeNode(myvalues[u]);
            }
            //assign to treeview 2
            treeView2.Nodes.AddRange(treeview2nodes);
            treeView2.Width = splitter1.Width;
            treeView2.NodeMouseClick += TreeView2_NodeMouseClick;
            //register a listener for the boundary onchange
         
            this.Resize += Form1_Resize;

          
          

            
        }

        private void TreeView2_NodeMouseClick(object? sender, TreeNodeMouseClickEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {
               
                //switch the text and update the treeview on the right 
                //accordingly
                switch (e.Node.Text)
                {
                    case "This PC":
                      
                        //get a list of the devices attached to this pc
                        DriveInfo[] mydrives = DriveInfo.GetDrives();
                        TreeNode[] drive_names = new TreeNode[mydrives.Length];
                        for(int i=0; i < mydrives.Length; i++)
                        {
                            drive_names[i]= new TreeNode(mydrives[i].Name);
                        }
                        treeView1.Nodes.Clear();
                        treeView1.Nodes.AddRange(drive_names);
                     
                        break;
                    case "Frequently Accessed":
                        MessageBox.Show("You clicked on this PC");
                        break;
                    case "Pictures":
                       
                        string ppath = "C:\\Users\\USER\\Pictures";
                        string[] dirs=Directory.GetDirectories(ppath); 
                        string[] fils=Directory.GetFiles(ppath);
                        TreeNode[] treeNodes= new TreeNode[fils.Length];
                        for(int i=0;i< fils.Length; i++)
                        {
                            treeNodes[i] = new TreeNode(fils[i]);
                        }
                        TreeNode[] treeNodes1 = new TreeNode[dirs.Length]; 
                        for(int r = 0; r < treeNodes1.Length; r++)
                        {
                            treeNodes1[r] = new TreeNode(dirs[r]);
                        }
                        //clear all nodes of treeview1
                        treeView1.Nodes.Clear();
                        treeView1.Nodes.AddRange(treeNodes1);
                        treeView1.Nodes.AddRange(treeNodes);
                        current_path = ppath;
                        //update the icons of the files and folders
                        CheckStatus();
                        break;
                    case "Documents":
                        string doc_path = "C:\\Users\\USER\\Documents";
                        string[] doc_files = Directory.GetFiles(doc_path);
                        string[] fol_files = Directory.GetDirectories(doc_path);
                        TreeNode[] docNodes = new TreeNode[doc_files.Length];
                        TreeNode[] docNodes2= new TreeNode[fol_files.Length];
                        for(int i = 0; i < docNodes.Length; i++)
                        {
                            docNodes[i] = new TreeNode(doc_files[i]);
                        }
                        for(int u = 0; u < fol_files.Length; u++)
                        {
                            docNodes2[u]=new TreeNode(fol_files[u]);    
                        }
                        //clear the nodes
                        treeView1.Nodes.Clear();
                        treeView1.Nodes.AddRange(docNodes);
                        treeView1.Nodes.AddRange(docNodes2);
                        current_path = doc_path;
                        CheckStatus();
                        break;

                    case "Videos":
                        MessageBox.Show("Videos");
                        break;

                }
            }
       
        }

        private void TextBox1_TextChanged(object? sender, EventArgs e)
        {
            //implement a filter on the treeview 
            //to remain with nodes that satisfy the required text
            if (textBox1.Text.Length > 0)
            {

                TreeNode[] search_results=treeView1.Nodes.Find(textBox1.Text,false);
               // MessageBox.Show(search_results.Length.ToString());
                //update the treeview with the searh results
               if(search_results.Length != 0)
                {
                    treeView1.Nodes.Clear();
                    treeView1.Nodes.AddRange(search_results);

                }
               
                
            }
           
        }

        private void Form1_Resize(object? sender, EventArgs e)
        {
            label2.Visible = true;
            label2.Text = current_path;
            currentpath.Visible = false;
            //get the width of the window
            int width = this.Width;
            //resize the treeview accordingly
            treeView1.Height = splitter1.Height;
            treeView1.Width = width - splitter1.Width;
           // MessageBox.Show("Window resized");
        }

        private void TreeView1_NodeMouseDoubleClick(object? sender, TreeNodeMouseClickEventArgs e)
        {
          if(e.Button == MouseButtons.Left)
            {
                //get the path clicked
                string pth = e.Node.Text;
                FileAttributes attributes=File.GetAttributes(pth);
                if (attributes.HasFlag(FileAttributes.Directory))
                {

                    //its a directory, clear the nodes and re assign
                    string[] n_files = Directory.GetFiles(pth);
                    string[] n_dirs = Directory.GetDirectories(pth);
                    if(n_files.Length > 0)
                    {
                        TreeNode[] file_nodes= new TreeNode[n_files.Length]; 
                        for (int i = 0; i < n_files.Length; i++)
                        {
                            file_nodes[i] = new TreeNode(n_files[i]);
                        }
                        TreeNode[] dir_nodes= new TreeNode[n_dirs.Length];
                        for(int i=0; i < n_dirs.Length; i++)
                        {
                            dir_nodes[i] = new TreeNode(n_dirs[i]);
                        }
                        //update the treeview
                        treeView1.Nodes.Clear();
                        treeView1.Nodes.AddRange(file_nodes);
                        treeView1.Nodes.AddRange(dir_nodes);
                        //update the file logo
                        CheckStatus();
                        //update the parent file
                        currentpath.Text=current_path;
                        label2.Text = current_path;
                    }
                }
            }
        }

       

        void CheckStatus()
        {
            for(int i = 0; i < treeView1.Nodes.Count; i++)
            {
                FileAttributes attr = File.GetAttributes(treeView1.Nodes[i].Text);
                if (attr.HasFlag(FileAttributes.Directory))
                {
                    //the node is a directory show 
                    //a folder icon
                    treeView1.Nodes[i].ImageIndex = 0;
                  
                }
                else
                {
                    //the node is a file, show a raw file
                    //icon
                    treeView1.Nodes[i].ImageIndex = 1;
                }
            }
        }

        private void Progress_update_Elapsed(object? sender, ElapsedEventArgs e)
        {
            //update the progressbar value
            pValue += 5;
            progress.Value=pValue;
          
            if (pValue == 100)
            {
                progress_update.Enabled = false;
                //dismiss the progress dialog
                progress.Hide();
            }

        }

        private void ContextMenuStrip2_ItemClicked(object? sender, ToolStripItemClickedEventArgs e)
        {
            //switch the index of the item clicked
            switch (e.ClickedItem.Text)
            {
                case "Copy":
                    //copy the path of the highlighted item to clipboard
                    copy_object = treeView1.SelectedNode.Text;
                    e.ClickedItem.Text = "Paste";
                    //show the progress bar
                  
                    break;
                case "Properties":
                    Properties props = new Properties();
                    Label mylabel = props.GetLabel;Label date_label = props.GetDateLabel;
                    mylabel.Text = File.Open(copy_object,FileMode.Open).Name;
                    DateTime creation_date = File.GetCreationTime(copy_object);
                    date_label.Text = creation_date.ToString();
                    props.ShowDialog();
                    
                    break;
                case "Open Source Folder":
                    //start a process to show windows explorer with 
                    //the current file highlighted
                    //split the item after the slash
                    MessageBox.Show(truncateToFolder(current_path));
                    Process.Start("explorer.exe",truncateToFolder(current_path));
                    
                    break;
                case "Sort":
                   
                    break;
                case "Paste":
                    //it is important to call the update timer 
                    //before showing the form to avoid showing a
                    //form with a progress dialog not updating

                    //do the file copy calculations here
                 
                    progress_update.Start();
                    form2.ShowDialog();
                    //update progress bar
                        try
                        {
                            File.Create(copy_object);
                            MessageBox.Show("File succesfully copied");
                        }catch(Exception m)
                        {
                            MessageBox.Show(m.Message);
                        }
                    break;
                case "Delete":
                    DeleteForm form = new DeleteForm();
                    form.ShowDialog();
                    break;
                case "Rename":
                    new Rename().ShowDialog();
                    break;
                
            }
        }

        private void TreeView1_NodeMouseClick(object? sender, TreeNodeMouseClickEventArgs e)
        {
            //highlight the selected node
            treeView1.SelectedNode = e.Node;
            //maintain the image
            //update the path variable with the text
            current_path=e.Node.Text;
            copy_object=e.Node.Text;    
            //check which mouse button sent this call
            if(e.Button == MouseButtons.Right)
            {
                //update the context location co-ordinates
                context_X = e.X;
                context_Y = e.Y;
                //its a right click so display the context menu
                //enable the rest of the file operations
                for(int i = 0; i < 3; i++)
                {
                    contextMenuStrip2.Items[i].Enabled = true;
                }
              contextMenuStrip2.Show(this,new Point(context_X,context_Y));

            }
        }

        private void moveUpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //get the items in the parent folder and attach to
            //the treeview
            DirectoryInfo parent_files=Directory.GetParent(current_path);
            if (parent_files!=null)
            {
                //update the path to use as child in the next
                //iteration
                path=parent_files.FullName;
                current_path = path;
                FileInfo[] children=parent_files.GetFiles();
                DirectoryInfo[] directoryInfos=parent_files.GetDirectories();
                //update the our treeview with the new File info
                TreeNode[] fileNodes= new TreeNode[children.Length];    
                for (int i = 0; i < children.Length; i++)
                {
                    fileNodes[i]=new TreeNode(children[i].FullName);
                }
                TreeNode[] directoryNodes= new TreeNode[directoryInfos.Length];
                //update with directories also
                for (int i = 0; i < directoryInfos.Length; i++)
                {
                    directoryNodes[i] = new TreeNode(directoryInfos[i].FullName);

                    //set a drawable to the right of a node to indicate its status
                }
                //clear the current range
                treeView1.Nodes.Clear();
                //update the range
                treeView1.Nodes.AddRange(fileNodes);
                treeView1.Nodes.AddRange(directoryNodes);
                CheckStatus();
                //update the current path display
                currentpath.Text = current_path;
                label2.Text = current_path;
            }
            
        }

     

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        string truncateToFolder(string path)
        {
            string ret = "";
            string[] parts = path.Split("\\");
            //get the last part of that string
            string last = parts[parts.Length - 1];
            //trim that part from our string
            ret = path.Trim(last.ToCharArray());
            return ret;
        }
        void SortByCreationTime(TreeNode[] nodes)
        {
            //use the selection sort algo to sort the nodes
            for(int i = 0; i < nodes.Length; i++)
            {
                for(int j=i+1;j<nodes.Length; j++)
                {
                    //implement a conditional structure on the time
                    if (File.GetCreationTime(nodes[i].Text) > File.GetCreationTime(nodes[j].Text)){
                        //swap the node index in the tree view array
                        TreeNode temp = nodes[i];
                        nodes[i] = nodes[j];
                        nodes[j] = temp;
                    }
                }
            }
        }
        //sort the files using selection sort using the merge algo
        void SortByFileSize(TreeNode[] nodes)
        {
            for(int i= 0; i< nodes.Length; i++)
            {
                for(int j = i + 1; j < nodes.Length; j++)
                {
                    //check if any file is being used
                    if (!File.OpenRead(nodes[i].Text).GetAccessControl().AreAccessRulesProtected)
                    {
                        //the file cannot be read because it is open
                        //in another program
                        MessageBox.Show("This file is open in another program, hence cannot be opened");
                       //exit the script
                        return;

                    }
                    if (File.Open(nodes[i].Text, FileMode.Open).Length > File.Open(nodes[j].Text, FileMode.Open).Length)
                    {
                        //swap the indices accordingly
                        TreeNode temp = nodes[i];
                        nodes[i]=nodes[j];
                        nodes[j]=temp;
                    }
                }
            }
        }

        private void ascendingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //clear the items first
            treeView1.Nodes.Clear();
            SortByCreationTime(listViewItems);
            //reassign the array to the treeview//update
            treeView1.Nodes.AddRange(listViewItems);
        }

        private void ascendingToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //clear the items first
            treeView1.Nodes.Clear();
            //sort the items
            SortByFileSize(listViewItems);
            //reassign the array to the treeview//update
            treeView1.Nodes.AddRange(listViewItems);
        }

        private void ascendingToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            //sort by name ascendingly
            string[] names = new string[listViewItems.Length - 1];
            for(int i = 0; i < names.Length; i++)
            {
                names[i] = listViewItems[i].Text;
            }
            Array.Sort(names);
            TreeNode[] sorted= new TreeNode[listViewItems.Length-1];
            for(int i = 0;i < names.Length; i++)
            {
                sorted[i] = new TreeNode(names[i]);
            }
            //clear the treenode
            treeView1.Nodes.Clear();
            treeView1.Nodes.AddRange(sorted);
            //associate the directories with the files
            CheckStatus();

        }

        private void darkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            treeView1.BackColor = Color.Black;
            treeView1.ForeColor = Color.Green;
            label1.ForeColor = Color.Green;
            date_display.ForeColor=Color.Green;
            Form1.ActiveForm.BackColor = Color.Black;
            treeView2.BackColor=Color.Black;
            treeView2.ForeColor = Color.Green;
        }

        private void lightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            treeView1.BackColor = Color.White;
            treeView1.ForeColor = Color.Blue;
            Form1.ActiveForm.BackColor = Color.White;
        }

        private void sourceCodeProToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //assign the required typeface to the whole application
           
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
          
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
        }
        //this method truncates the names to relative file
        //names
       string RelativeName(string pt)
        {
            string[] names =pt.Split("\\");
            //get the last part
            string last = names[names.Length - 1];
            //return the last part
            return last;
        }
        string[] RelativePathNames(string[] paths)
        {
            string[] vs =new string[paths.Length];
            for (int i = 0; i < paths.Length; i++)
            {
                vs[i] = RelativeName(paths[i]);
            }
            return vs;
        }

        private void relativePathToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            string[] relative_paths = new string[listViewItems.Length];
            relative_paths = Directory.GetFiles(current_path);
            items = new TreeNode[relative_paths.Length];
            for(int i=0;i< relative_paths.Length; i++)
            {
                items[i] =new TreeNode(RelativeName(relative_paths[i]));
            }
            //update the treeview
            treeView1.Nodes.Clear();
            treeView1.Nodes.AddRange(items);
            //CheckStatus();
            //update the icons using a custom loop
            for(int i = 0; i < treeView1.Nodes.Count; i++)
            {
                FileAttributes attr= File.GetAttributes(current_path+"\\"+treeView1.Nodes[i].Text);
                if (attr.HasFlag(FileAttributes.Directory)){
                    //use the image in the index zero of the image list
                    treeView1.Nodes[i].ImageIndex = 0;
                }
                else
                {
                    treeView1.Nodes[i].ImageIndex = 1;
                }
            }
        }

        private void absolutePathToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //switch back to the list view items

            string[] files=Directory.GetFiles(current_path);
            TreeNode[] nodes = new TreeNode[files.Length];
            for(int i = 0; i < nodes.Length; i++)
            {
                nodes[i] = new TreeNode(files[i]);
            }
            treeView1.Nodes.Clear();
            treeView1.Nodes.AddRange(nodes);
            CheckStatus();
        }

        private void openInTerminalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //start cmd with the specified path
            Process.Start("cmd.exe", current_path);
        }
    }
   
  
    
}